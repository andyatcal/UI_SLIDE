#ifndef __ITCLCXX_INIT_H__
#define __ITCLCXX_INIT_H__

#include "itclcxx_defs.h"

#ifdef WIN32

#include <tcl.h>

extern "C" {
  ITCLCXX_API int Itclcxx_Init(Tcl_Interp *pInterp);
}

#else // WIN32

// Unix

#endif // WIN32

#endif // __ITCLCXX_INIT_H__
