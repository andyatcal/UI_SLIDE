#ifndef __ITCLCXX_DEFS_H__
#define __ITCLCXX_DEFS_H__

#ifdef WIN32

#ifdef ITCLCXX_EXPORTS
#define ITCLCXX_API __declspec(dllexport)
#else
#define ITCLCXX_API __declspec(dllimport)
#endif

#else // WIN32

// Unix

#define ITCLCXX_API 

#endif // WIN32

#endif // __ITCLCXX_DEFS_H__
