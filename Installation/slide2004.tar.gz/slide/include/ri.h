/*************************************************************************
 * ri.h - header file for the Blue Moon Rendering Tools (BMRT), which    *
 *        adheres to the Pixar RenderMan Interface standard.             *
 *                                                                       *
 * The Blue Moon Rendering Tools (BMRT) are:                             *
 * (c) Copyright 1990-1994 by Larry I. Gritz.  All rights reserved.      *
 *                                                                       *
 * The RenderMan (R) Interface Procedures and RIB Protocol are:          *
 *      Copyright 1988, 1989, Pixar.  All rights reserved.               *
 * RenderMan (R) is a registered trademark of Pixar.                     *
 *************************************************************************/

#ifndef RI_H
#define RI_H 1

#ifdef __cplusplus
extern "C" {
#endif

typedef short   RtBoolean;
typedef int     RtInt;
typedef float   RtFloat;

typedef char   *RtToken;

#ifndef NCOMPS
#define NCOMPS 3
#endif

typedef RtFloat RtColor[NCOMPS];
typedef RtFloat RtPoint[3];
typedef RtFloat RtMatrix[4][4];
typedef RtFloat RtBasis[4][4];
typedef RtFloat RtBound[6];
typedef char   *RtString;

typedef char   *RtPointer;
#ifdef __cplusplus
#define RtVoid void
/* typedef void    RtVoid; */
#else
typedef void    RtVoid;
#endif
typedef RtFloat (*RtFilterFunc)(RtFloat, RtFloat, RtFloat, RtFloat);
typedef RtVoid  (*RtErrorHandler)(RtInt code, RtInt severity, char *msg);
typedef RtVoid  (*RtFunc)();

typedef RtPointer RtObjectHandle;
typedef RtPointer RtLightHandle;

#define RI_FALSE    0
#define RI_TRUE     1
#define RI_INFINITY (RtFloat)1.0e38
#define RI_EPSILON  (RtFloat)1.0e-10

#ifndef NULL
#define NULL 0
#endif
#define RI_NULL NULL


extern RtToken  RI_FRAMEBUFFER, RI_FILE;
extern RtToken  RI_RGB, RI_RGBA, RI_RGBZ, RI_RGBAZ, RI_A, RI_Z, RI_AZ;
extern RtToken  RI_PERSPECTIVE, RI_ORTHOGRAPHIC;
extern RtToken  RI_HIDDEN, RI_PAINT;
extern RtToken  RI_CONSTANT, RI_SMOOTH;
extern RtToken  RI_FLATNESS, RI_FOV;

extern RtToken  RI_AMBIENTLIGHT, RI_POINTLIGHT, RI_DISTANTLIGHT, RI_SPOTLIGHT;
extern RtToken  RI_INTENSITY, RI_LIGHTCOLOR, RI_FROM, RI_TO, RI_CONEANGLE,
                RI_CONEDELTAANGLE, RI_BEAMDISTRIBUTION;
extern RtToken  RI_MATTE, RI_METAL, RI_SHINYMETAL,
                RI_PLASTIC, RI_PAINTEDPLASTIC;
extern RtToken  RI_KA, RI_KD, RI_KS, RI_ROUGHNESS, RI_KR,
                RI_TEXTURENAME, RI_SPECULARCOLOR;
extern RtToken  RI_DEPTHCUE, RI_FOG, RI_BUMPY;
extern RtToken  RI_MINDISTANCE, RI_MAXDISTANCE, RI_BACKGROUND,
                RI_DISTANCE, RI_AMPLITUDE;

extern RtToken  RI_RASTER, RI_SCREEN, RI_CAMERA, RI_WORLD, RI_OBJECT;
extern RtToken  RI_INSIDE, RI_OUTSIDE, RI_LH, RI_RH;
extern RtToken  RI_P, RI_PZ, RI_PW, RI_N, RI_NP, RI_CS,
                RI_OS, RI_S, RI_T, RI_ST;
extern RtToken  RI_BILINEAR, RI_BICUBIC;
extern RtToken  RI_PRIMITIVE, RI_INTERSECTION, RI_UNION, RI_DIFFERENCE;
extern RtToken  RI_PERIODIC, RI_NONPERIODIC, RI_CLAMP, RI_BLACK;
extern RtToken  RI_IGNORE, RI_PRINT, RI_ABORT, RI_HANDLER;
extern RtToken  RI_ORIGIN, RI_IDENTIFIER, RI_NAME;
extern RtToken  RI_COMMENT, RI_STRUCTURE;
extern RtToken  RI_LINEAR, RI_CUBIC, RI_WIDTH, RI_CONSTANTWIDTH;

extern RtToken  RI_CURRENT, RI_WORLD, RI_OBJECT, RI_SHADER;
extern RtToken  RI_RASTER, RI_NDC, RI_SCREEN, RI_CAMERA, RI_EYE;

extern RtBasis  RiBezierBasis, RiBSplineBasis, RiCatmullRomBasis,
                RiHermiteBasis, RiPowerBasis;

#define RI_BEZIERSTEP       ((RtInt)3)
#define RI_BSPLINESTEP      ((RtInt)1)
#define RI_CATMULLROMSTEP   ((RtInt)1)
#define RI_HERMITESTEP      ((RtInt)2)
#define RI_POWERSTEP        ((RtInt)4)

extern RtInt RiLastError;



/* Delarations of All of the RenderMan Interface Subroutines */

#if (defined(__STDC__) || defined(__cplusplus))

extern RtToken
    RiDeclare (char *name, char *declaration);

extern RtVoid
    RiBegin (RtToken name), RiEnd (void),
    RiFrameBegin (RtInt number), RiFrameEnd (void),
    RiWorldBegin (void), RiWorldEnd (void);

extern RtVoid
    RiFormat (RtInt xres, RtInt yres, RtFloat aspect),
    RiFrameAspectRatio (RtFloat aspect),
    RiScreenWindow (RtFloat left, RtFloat right, RtFloat bot, RtFloat top),
    RiCropWindow (RtFloat xmin, RtFloat xmax, RtFloat ymin, RtFloat ymax),
    RiProjection (char *name, ...),
    RiProjectionV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiClipping (RtFloat hither, RtFloat yon),
    RiDepthOfField (RtFloat fstop, RtFloat focallength, RtFloat focaldistance),
    RiShutter (RtFloat smin, RtFloat smax);

extern RtVoid
    RiPixelVariance (RtFloat variation),
    RiPixelSamples (RtFloat xsamples, RtFloat ysamples),
    RiPixelFilter (RtFilterFunc function, RtFloat xwidth, RtFloat ywidth),
    RiExposure (RtFloat gain, RtFloat gamma),
    RiImager (char *name, ...),
    RiImagerV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiQuantize (RtToken type, RtInt one, RtInt qmin, RtInt qmax, RtFloat ampl),
    RiDisplay (char *name, RtToken type, RtToken mode, ...),
    RiDisplayV (char *name, RtToken type, RtToken mode,
		RtInt n, RtToken tokens[], RtPointer params[]);

extern RtFloat
    RiGaussianFilter (RtFloat x, RtFloat y, RtFloat xwidth, RtFloat ywidth),
    RiBoxFilter (RtFloat x, RtFloat y, RtFloat xwidth, RtFloat ywidth),
    RiTriangleFilter (RtFloat x, RtFloat y, RtFloat xwidth, RtFloat ywidth),
    RiCatmullRomFilter (RtFloat x, RtFloat y, RtFloat xwidth, RtFloat ywidth),
    RiSincFilter (RtFloat x, RtFloat y, RtFloat xwidth, RtFloat ywidth);

extern RtVoid
    RiHider (RtToken type, ...),
    RiHiderV (RtToken type, RtInt n, RtToken tokens[], RtPointer params[]),
    RiColorSamples (RtInt N, RtFloat *nRGB, RtFloat *RGBn),
    RiRelativeDetail (RtFloat relativedetail),
    RiOption (char *name, ...),
    RiOptionV (char *name, RtInt n, RtToken tokens[], RtPointer params[]);

extern RtVoid
    RiAttributeBegin (void), RiAttributeEnd (void),
    RiColor (RtColor Cs), RiOpacity (RtColor Cs),
    RiTextureCoordinates (RtFloat s1, RtFloat t1, RtFloat s2, RtFloat t2,
			  RtFloat s3, RtFloat t3, RtFloat s4, RtFloat t4);

extern RtLightHandle
    RiLightSource (char *name, ...),
    RiLightSourceV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiAreaLightSource (char *name, ...),
    RiAreaLightSourceV (char *name, RtInt n,
			RtToken tokens[], RtPointer params[]);

extern RtVoid
    RiIlluminate (RtLightHandle light, RtBoolean onoff),
    RiSurface (char *name, ...),
    RiSurfaceV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiAtmosphere (char *name, ...),
    RiAtmosphereV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiInterior (char *name, ...),
    RiInteriorV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiExterior (char *name, ...),
    RiExteriorV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiShadingRate (RtFloat size),
    RiShadingInterpolation (RtToken type),
    RiMatte (RtBoolean onoff);

extern RtVoid
    RiBound (RtBound bound), RiDetail (RtBound bound),
    RiDetailRange (RtFloat minvis, RtFloat lowtran,
		   RtFloat uptran, RtFloat maxvis),
    RiGeometricApproximation (RtToken type, RtFloat value),
    RiGeometricRepresentation (RtToken type),
    RiOrientation (RtToken orientation), RiReverseOrientation (void),
    RiSides (RtInt nsides);

extern RtVoid
    RiIdentity (void),
    RiTransform (RtMatrix transform), RiConcatTransform (RtMatrix transform),
    RiPerspective (RtFloat fov),
    RiTranslate (RtFloat dx, RtFloat dy, RtFloat dz),
    RiRotate (RtFloat angle, RtFloat dx, RtFloat dy, RtFloat dz),
    RiScale (RtFloat dx, RtFloat dy, RtFloat dz),
    RiSkew (RtFloat angle, RtFloat dx1, RtFloat dy1, RtFloat dz1,
	    RtFloat dx2, RtFloat dy2, RtFloat dz2),
    RiDeformation (char *name, ...),
    RiDeformationV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiDisplacement (char *name, ...),
    RiDisplacementV (char *name, RtInt n, RtToken tokens[], RtPointer params[]),
    RiCoordinateSystem (RtToken space),
    RiCoordSysTransform (RtToken space);

extern RtPoint *RiTransformPoints (RtToken fromspace, RtToken tospace,
				   RtInt npoints, RtPoint *points);

extern RtVoid RiTransformBegin (void), RiTransformEnd (void);

extern RtVoid
    RiAttribute (char *name, ...),
    RiAttributeV (char *name, RtInt n, RtToken tokens[], RtPointer params[]);

extern RtVoid
    RiPolygon (RtInt nvertices, ...),
    RiPolygonV (RtInt nvertices, RtInt n, RtToken tokens[], RtPointer params[]),
    RiGeneralPolygon (RtInt nloops, RtInt *nverts, ...),
    RiGeneralPolygonV (RtInt nloops, RtInt *nverts,
		       RtInt n, RtToken tokens[], RtPointer params[]),
    RiPointsPolygons (RtInt npolys, RtInt *nverts, RtInt *verts, ...),
    RiPointsPolygonsV (RtInt npolys, RtInt *nverts, RtInt *verts, 
		      RtInt n, RtToken tokens[], RtPointer params[]),
    RiPointsGeneralPolygons (RtInt npolys, RtInt *nloops,
			     RtInt *nverts, RtInt *verts, ...),
    RiPointsGeneralPolygonsV (RtInt npolys, RtInt *nloops,
			     RtInt *nverts, RtInt *verts, 
			      RtInt n, RtToken tokens[], RtPointer params[]),
    RiBasis (RtBasis ubasis, RtInt ustep, RtBasis vbasis, RtInt vstep),
    RiPatch (RtToken type, ...),
    RiPatchV (RtToken type, RtInt n, RtToken tokens[], RtPointer params[]),
    RiPatchMesh (RtToken type, RtInt nu, RtToken uwrap,
		 RtInt nv, RtToken vwrap, ...),
    RiPatchMeshV (RtToken type, RtInt nu, RtToken uwrap, RtInt nv,
		  RtToken vwrap, RtInt n, RtToken tokens[], RtPointer params[]),
    RiNuPatch (RtInt nu, RtInt uorder, RtFloat *uknot,
	       RtFloat umin, RtFloat umax, RtInt nv, RtInt vorder,
	       RtFloat *vknot, RtFloat vmin, RtFloat vmax, ...),
    RiNuPatchV (RtInt nu, RtInt uorder, RtFloat *uknot,
		RtFloat umin, RtFloat umax, RtInt nv, RtInt vorder,
		RtFloat *vknot, RtFloat vmin, RtFloat vmax, 
		RtInt n, RtToken tokens[], RtPointer params[]),
    RiTrimCurve (RtInt nloops, RtInt *ncurves, RtInt *order,
		 RtFloat *knot, RtFloat *amin, RtFloat *amax,
		 RtInt *n, RtFloat *u, RtFloat *v, RtFloat *w);

extern RtVoid
    RiSphere (RtFloat radius, RtFloat zmin,
	      RtFloat zmax, RtFloat thetamax, ...),
    RiSphereV (RtFloat radius, RtFloat zmin, RtFloat zmax, RtFloat thetamax,
	       RtInt n, RtToken tokens[], RtPointer params[]),
    RiCone (RtFloat height, RtFloat radius, RtFloat thetamax, ...),
    RiConeV (RtFloat height, RtFloat radius, RtFloat thetamax, 
	    RtInt n, RtToken tokens[], RtPointer params[]),
    RiCylinder (RtFloat radius, RtFloat zmin, RtFloat zmax, 
		RtFloat thetamax, ...),
    RiCylinderV (RtFloat radius, RtFloat zmin, RtFloat zmax, RtFloat thetamax,
		 RtInt n, RtToken tokens[], RtPointer params[]),
    RiHyperboloid (RtPoint point1, RtPoint point2, RtFloat thetamax, ...),
    RiHyperboloidV (RtPoint point1, RtPoint point2, RtFloat thetamax, 
		   RtInt n, RtToken tokens[], RtPointer params[]),
    RiParaboloid (RtFloat rmax, RtFloat zmin,
		  RtFloat zmax, RtFloat thetamax, ...),
    RiParaboloidV (RtFloat rmax, RtFloat zmin, RtFloat zmax, RtFloat thetamax, 
		   RtInt n, RtToken tokens[], RtPointer params[]),
    RiDisk (RtFloat height, RtFloat radius, RtFloat thetamax, ...),
    RiDiskV (RtFloat height, RtFloat radius, RtFloat thetamax, 
	     RtInt n, RtToken tokens[], RtPointer params[]),
    RiTorus (RtFloat majorrad, RtFloat minorrad, RtFloat phimin,
	     RtFloat phimax, RtFloat thetamax, ...),
    RiTorusV (RtFloat majorrad, RtFloat minorrad, RtFloat phimin,
	     RtFloat phimax, RtFloat thetamax,
	      RtInt n, RtToken tokens[], RtPointer params[]),
    RiCurves (RtToken degree, RtInt ncurves, RtInt nverts[], RtToken wrap, ...),
    RiCurvesV (RtToken degree, RtInt ncurves, RtInt nverts[], RtToken wrap, 
	      RtInt n, RtToken tokens[], RtPointer params[]),
    RiProcedural (RtPointer data, RtBound bound,
		  RtVoid (*subdivfunc) (RtPointer, RtFloat),
		  RtVoid (*freefunc) (RtPointer)),
    RiGeometry (RtToken type, ...),
    RiGeometryV (RtToken type, RtInt n, RtToken tokens[], RtPointer params[]);

extern RtVoid
    RiCurves (RtToken degree, RtInt ncurves,
	      RtInt nverts[], RtToken wrap, ...),
    RiCurvesV (RtToken degree, RtInt ncurves, RtInt nverts[], RtToken wrap,
	       RtInt n, RtToken tokens[], RtPointer params[]),
    RiPoints (RtInt npts,...),
    RiPointsV (RtInt npts, RtInt n, RtToken tokens[], RtPointer params[]),
    RiSubdivisionMesh (RtToken scheme, RtInt nfaces,
		       RtInt nvertices[], RtInt vertices[],
		       RtInt ntags, RtToken tags[], RtInt nargs[],
		       RtInt intargs[], RtFloat floatargs[], ...),
    RiSubdivisionMeshV (RtToken scheme, RtInt nfaces,
		       RtInt nvertices[], RtInt vertices[],
		       RtInt ntags, RtToken tags[], RtInt nargs[],
		       RtInt intargs[], RtFloat floatargs[], 
		       RtInt n, RtToken tokens[], RtPointer params[]);

extern RtVoid RiProcDelayedReadArchive (RtPointer data, RtFloat detail),
    RiProcRunProgram (RtPointer data, RtFloat detail),
    RiProcDynamicLoad (RtPointer data, RtFloat detail);

extern RtVoid RiSolidBegin (RtToken type), RiSolidEnd(void);
extern RtObjectHandle RiObjectBegin (void);

extern RtVoid
    RiObjectEnd (void),
    RiObjectInstance (RtObjectHandle handle),
    RiMotionBegin (RtInt N, ...),
    RiMotionBeginV (RtInt N, RtFloat times[]),
    RiMotionEnd (void);

extern RtVoid
    RiMakeTexture (char *pic, char *tex, RtToken swrap, RtToken twrap,
		   RtFilterFunc filterfunc, RtFloat swidth, RtFloat twidth, ...),
    RiMakeTextureV (char *pic, char *tex, RtToken swrap, RtToken twrap,
		    RtFilterFunc filterfunc, RtFloat swidth, RtFloat twidth,
		    RtInt n, RtToken tokens[], RtPointer params[]),
    RiMakeBump (char *pic, char *tex, RtToken swrap, RtToken twrap,
		RtFilterFunc filterfunc, RtFloat swidth, RtFloat twidth, ...),
    RiMakeBumpV (char *pic, char *tex, RtToken swrap, RtToken twrap,
		 RtFilterFunc filterfunc, RtFloat swidth, RtFloat twidth,
		 RtInt n, RtToken tokens[], RtPointer params[]),
    RiMakeLatLongEnvironment (char *pic, char *tex, RtFilterFunc filterfunc,
			      RtFloat swidth, RtFloat twidth, ...),
    RiMakeLatLongEnvironmentV (char *pic, char *tex, RtFilterFunc filterfunc,
			      RtFloat swidth, RtFloat twidth,
			       RtInt n, RtToken tokens[], RtPointer params[]),
    RiMakeCubeFaceEnvironment (char *px, char *nx, char *py,
			       char *ny, char *pz, char *nz,
			       char *tex, RtFloat fov, RtFilterFunc filterfunc,
			       RtFloat swidth, RtFloat twidth, ...),
    RiMakeCubeFaceEnvironmentV (char *px, char *nx, char *py,
				char *ny, char *pz, char *nz,
				char *tex, RtFloat fov, RtFilterFunc filterfunc,
				RtFloat swidth, RtFloat twidth,
				RtInt n, RtToken tokens[], RtPointer params[]),
    RiMakeShadow (char *pic, char *tex, ...),
    RiMakeShadowV (char *pic, char *tex,
		   RtInt n, RtToken tokens[], RtPointer params[]);

extern RtVoid
    RiErrorHandler (RtErrorHandler handler),
    RiErrorIgnore (RtInt code, RtInt severity, char *message),
    RiErrorPrint (RtInt code, RtInt severity, char *message),
    RiErrorAbort (RtInt code, RtInt severity, char *message);

extern RtVoid
    RiArchiveRecord (RtToken type, char *format, ...),
    RiArchiveRecordV (RtToken type, char *format,
		      RtInt n, RtToken tokens[], RtPointer params[]),
    RiReadArchive (RtString filename, RtFunc callback, ...),
    RiReadArchiveV (RtString filename, RtFunc callback,
		    int n, RtToken tokens[], RtPointer params[]);

#else


extern RtToken RiDeclare ();

extern RtVoid
    RiBegin (), RiEnd (), RiFrameBegin (), RiFrameEnd (),
    RiWorldBegin (), RiWorldEnd ();

extern RtVoid
    RiFormat (), RiFrameAspectRatio (), RiScreenWindow (),
    RiCropWindow (), RiProjection (), RiProjectionV (),
    RiClipping (), RiDepthOfField (), RiShutter ();

extern RtVoid
    RiPixelVariance (), RiPixelSamples (), RiPixelFilter (),
    RiExposure (), RiImager (), RiImagerV (),
    RiQuantize (), RiDisplay (), RiDisplayV ();

extern RtFloat  RiGaussianFilter (), RiBoxFilter (), RiTriangleFilter (),
                RiCatmullRomFilter (), RiSincFilter ();

extern RtVoid   RiHider (), RiHiderV (), RiColorSamples (),
                RiRelativeDetail (), RiOption (), RiOptionV ();

extern RtVoid   RiAttributeBegin (), RiAttributeEnd (),
                RiColor (), RiOpacity (), RiTextureCoordinates ();

extern RtLightHandle RiLightSource (), RiLightSourceV (),
                RiAreaLightSource (), RiAreaLightSourceV ();
extern RtVoid   RiIlluminate ();

extern RtVoid
    RiSurface (), RiSurfaceV (), RiAtmosphere (), RiAtmosphereV (),
    RiInterior (), RiInteriorV (), RiExterior (), RiExteriorV (),
    RiShadingRate (), RiShadingInterpolation (), RiMatte ();

extern RtVoid  RiBound (), RiDetail (), RiDetailRange (),
    RiGeometricApproximation (), RiOrientation (),
    RiReverseOrientation (), RiSides ();

extern RtVoid
    RiIdentity (), RiTransform (), RiConcatTransform (),
    RiPerspective (), RiTranslate (), RiRotate (), RiScale (),
    RiSkew (), RiDeformation (), RiDeformationV (),
    RiDisplacement (), RiDisplacementV (), RiCoordinateSystem (),
    RiCoordSysTransform ();

extern RtPoint  *RiTransformPoints ();

extern RtVoid   RiTransformBegin (), RiTransformEnd ();

extern RtVoid   RiAttribute (), RiAttributeV ();

extern RtVoid
    RiPolygon (), RiPolygonV(), RiGeneralPolygon (), RiGeneralPolygonV (),
    RiPointsPolygons (), RiPointsPolygonsV (),
    RiPointsGeneralPolygons (), RiPointsGeneralPolygonsV (),
    RiBasis (), RiPatch (), RiPatchV (), RiPatchMesh (), RiPatchMeshV (),
    RiNuPatch (), RiNuPatchV (), RiTrimCurve ();

extern RtVoid 
    RiSphere (), RiSphereV (), RiCone (), RiConeV (),
    RiCylinder (), RiCylinderV (), RiHyperboloid (), RiHyperboloidV (),
    RiParaboloid (), RiParaboloidV (), RiDisk (), RiDiskV (),
    RiTorus (), RiTorusV (), RiCurves (), RiCurvesV(), RiProcedural (),
    RiGeometry (), RiGeometryV (), RiCurves (), RiCurvesV(),
    RiPoints(), RiPointsV(), RiSubdivisionMesh(), RiSubdivisionMeshV();

extern RtVoid   RiSolidBegin (), RiSolidEnd ();
extern RtObjectHandle RiObjectBegin ();
extern RtVoid   RiObjectEnd (), RiObjectInstance (),
                RiMotionBegin (), RiMotionBeginV (), RiMotionEnd ();

extern RtVoid
    RiMakeTexture (), RiMakeTextureV (), RiMakeBump (), RiMakeBumpV (),
    RiMakeLatLongEnvironment (), RiMakeLatLongEnvironmentV (),
    RiMakeCubeFaceEnvironment (), RiMakeCubeFaceEnvironmentV (),
    RiMakeShadow (), RiMakeShadowV ();

extern RtVoid RiErrorHandler (), RiErrorIgnore (),
    RiErrorPrint (), RiErrorAbort ();

extern RtVoid RiArchiveRecord (), RiArchiveRecordV ();
extern RtVoid RiReadArchive (), RiReadArchiveV ();

#endif



/*
    Error codes

     1 - 10     System and File errors
    11 - 20     Program Limitations
    21 - 40     State Errors
    41 - 60     Parameter and Protocol Errors
    61 - 80     Execution Errors
*/

#define RIE_NOERROR         0

#define RIE_NOMEM           1       /* Out of memory */
#define RIE_SYSTEM          2       /* Miscellaneous system error */
#define RIE_NOFILE          3       /* File nonexistant */
#define RIE_BADFILE         4       /* Bad file format */
#define RIE_VERSION         5       /* File version mismatch */

#define RIE_INCAPABLE      11       /* Optional RI feature */
#define RIE_OPTIONAL       11       /* Optional RI feature */
#define RIE_UNIMPLEMENT    12       /* Unimplemented feature */
#define RIE_LIMIT          13       /* Arbitrary program limit */
#define RIE_BUG            14       /* Probably a bug in renderer */

#define RIE_NOTSTARTED     23       /* RiBegin not called */
#define RIE_NESTING        24       /* Bad begin-end nesting */
#define RIE_NOTOPTIONS     25       /* Invalid state for options */
#define RIE_NOTATTRIBS     26       /* Invalid state for attributes */
#define RIE_NOTPRIMS       27       /* Invalid state for primitives */
#define RIE_ILLSTATE       28       /* Other invalid state */
#define RIE_BADMOTION      29       /* Badly formed motion block */
#define RIE_BADSOLID       30       /* Badly formed solid block */

#define RIE_BADTOKEN       41       /* Invalid token for request */
#define RIE_RANGE          42       /* Parameter out of range */
#define RIE_CONSISTENCY    43       /* Parameters inconsistent */
#define RIE_BADHANDLE      44       /* Bad object/light handle */
#define RIE_NOSHADER       45       /* Can't load requested shader */
#define RIE_MISSINGDATA    46       /* Required parameters not provided */
#define RIE_SYNTAX         47       /* Declare type syntax error */

#define RIE_MATH           61       /* Zerodivide, noninvert matrix, etc. */


/* Error severity levels */

#define RIE_INFO            0       /* Rendering stats & other info */
#define RIE_WARNING         1       /* Something seems wrong, maybe okay */
#define RIE_ERROR           2       /* Problem.  Results may be wrong */
#define RIE_SEVERE          3       /* So bad you should probably abort */

#ifdef __cplusplus
}
#endif


#endif  /* RI_H */

