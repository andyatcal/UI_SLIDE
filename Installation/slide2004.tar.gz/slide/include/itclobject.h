#ifndef __ITCLOBJECT_H__
#define __ITCLOBJECT_H__

#include "itclcxx_defs.h"
#include "genlib.h"

#include <tcl.h>
#include "dispatch.h"

//////////////////////////////////////////////////////////////////////
// Parameter Types

class ItclObject;
class ItclObjectEntry;
class ItclMethodEntry;
class ItclFieldEntry;
class ItclClassEntry;
class ItclNameSpace;

typedef ItclObject *(ItclObjectAllocateFunc) ();
typedef void (ItclObjectDeallocateFunc) (ItclObject *);


//////////////////////////////////////////////////////////////////////
// ItclObjectEntry

class ItclObjectEntry
{
public:
  ItclObjectEntry();
  ~ItclObjectEntry();
  int Init(ItclNameSpace *pNameSpace, 
	   ItclClassEntry *pClass, 
	   ItclObject *pObject, char *pcName);
  int Uninit();

public:
  static int CommandCmd(ClientData pvObjectEntry, Tcl_Interp *pInterp, 
			int argc, char *argv[]);
  int Command(Tcl_Interp *pInterp, int argc, char *argv[]);

public:
  inline ItclClassEntry *GetClassEntry() {return m_pClass;};
  inline ItclObject *GetObject() {return m_pObject;};
  inline char *GetName() {return m_pcName;};

protected:
  ItclNameSpace *m_pNameSpace;
  ItclClassEntry *m_pClass;
  ItclObject *m_pObject;
  char *m_pcName;
};

//////////////////////////////////////////////////////////////////////
// ItclMethodEntry

class ItclMethodEntry
{
public:
  ItclMethodEntry();
  ~ItclMethodEntry();
  int Init(char *pcName, 
	   ItclClassEntry *pClass,
	   Itcl_Method *pufpMethod, 
	   ItclReturnType eReturnType, 
	   ItclParametersType eParametersType,
	   char *pcTclParameters);
  int Uninit();

public:
  inline char *GetName() {return m_pcName;};
  inline ItclClassEntry *GetClass() {return m_pClass;};
  inline ItclMethod *GetMethod() {return &m_method;};
  inline ItclReturnType GetReturnType() {return m_method.eReturnType;};
  inline ItclParametersType GetParametersType() {return m_method.eParametersType;};
  inline char *GetTclParameters() {return m_pcTclParameters;};

protected:
  char *m_pcName;
  ItclClassEntry *m_pClass;
  ItclMethod m_method;
  char *m_pcTclParameters;
};

//////////////////////////////////////////////////////////////////////
// ItclFieldEntry

class ItclFieldEntry
{
public:
  ItclFieldEntry();
  ~ItclFieldEntry();
  int Init(char *pcName, 
	   ItclClassEntry *pClass,
	   Itcl_Method *pufpMethodGet, 
	   ItclReturnType eReturnTypeGet, 
	   ItclParametersType eParametersTypeGet,
	   Itcl_Method *pufpMethodSet, 
	   ItclReturnType eReturnTypeSet, 
	   ItclParametersType eParametersTypeSet);
  int Uninit();

public:
  inline char *GetName() {return m_pcName;};
  inline ItclClassEntry *GetClassEntry() {return m_pClass;};
  inline ItclMethod *GetMethodGet() {return &m_methodGet;};
  inline ItclReturnType GetReturnTypeGet() {return m_methodGet.eReturnType;};
  inline ItclParametersType GetParametersTypeGet() {return m_methodGet.eParametersType;};
  inline ItclMethod *GetMethodSet() {return &m_methodSet;};
  inline ItclReturnType GetReturnTypeSet() {return m_methodSet.eReturnType;};
  inline ItclParametersType GetParametersTypeSet() {return m_methodSet.eParametersType;};

protected:
  char *m_pcName;
  ItclClassEntry *m_pClass;
  ItclMethod m_methodGet;
  ItclMethod m_methodSet;
};

//////////////////////////////////////////////////////////////////////
// ItclClassEntry

class ItclClassEntry
{
public:
  ITCLCXX_API ItclClassEntry();
  ITCLCXX_API ~ItclClassEntry();
  ITCLCXX_API int Init(Tcl_Interp *pInterp, 
	   ItclNameSpace *pNameSpace,
	   ItclClassEntry *pParent, 
	   char *pcName,
	   ItclObjectAllocateFunc *fpAllocate, 
	   ItclObjectDeallocateFunc *fpDeallocate);
  ITCLCXX_API int Uninit(Tcl_Interp *pInterp);

public:
  static int ClassCmd(ClientData pvClassEntry, Tcl_Interp *pInterp, 
		      int argc, char *argv[]);
  int CreateObject(Tcl_Interp *pInterp, int argc, char *argv[]);
  int DestroyObject(Tcl_Interp *pInterp, ItclObjectEntry *pObjectEntry);

protected:
  int CreateObjectFields(Tcl_Interp *pInterp, ItclObjectEntry *pObjectEntry);
  int DestroyObjectFields(Tcl_Interp *pInterp, ItclObjectEntry *pObjectEntry);

public:
  ITCLCXX_API int CreateMethodEntry(char *pcMethodName, 
			Itcl_Method *pufpMethod, 
			ItclReturnType eReturnType, 
			ItclParametersType eParametersType,
			char *pcTclParameters);
  ITCLCXX_API int CreateFieldEntry(char *pcName, 
		       Itcl_Method *pufpMethodGet, 
		       ItclReturnType eReturnTypeGet, 
		       ItclParametersType eParametersTypeGet,
		       Itcl_Method *pufpMethodSet, 
		       ItclReturnType eReturnTypeSet, 
		       ItclParametersType eParametersTypeSet);
  ItclClassEntry *FindSuperClass(char *pcClassName);

public:
  ItclMethodEntry *FindMethodEntry(char *pcFullMethodName);
protected:
  ItclMethodEntry *FindMethodEntryRecursive(char *pcMethodName);  

public:
  ItclFieldEntry *FindFieldEntry(char *pcFullFieldName);
protected:
  ItclFieldEntry *FindFieldEntryRecursive(char *pcFieldName);  

public:
  void CreateInfoHeritageString(char *pcHeritage);
  void CreateInfoInheritString(char *pcInherit);
  void CreateInfoFunctionsString(char *pcFunctions);
  void CreateInfoFieldsString(char *pcFields);
  void CreateConfigureFieldsString(char *pcFields, ItclObject *pObject);

public:
  inline char *GetName() {return m_pcName;};
  inline ItclClassEntry *GetParent() {return m_pParent;};

protected:
  int m_bInitialized;
  ItclNameSpace *m_pNameSpace;
  ItclClassEntry *m_pParent;
  char *m_pcName;
  unsigned int m_uiObjectCounter;
  Tcl_HashTable m_hashObjects;  
  Tcl_HashTable m_hashMethods;  
  Tcl_HashTable m_hashFields;  

  ItclObjectAllocateFunc *m_fpAllocate;
  ItclObjectDeallocateFunc *m_fpDeallocate;
};

//////////////////////////////////////////////////////////////////////
// ItclNameSpace

class ItclNameSpace
{
public:
  ItclNameSpace();
  ~ItclNameSpace();
  int Init(Tcl_Interp *pInterp);
  void Uninit();

public:
  int CreateClassEntry(ItclClassEntry *pClassEntry);
  int DestroyClassEntry(ItclClassEntry *pClassEntry);
  ItclClassEntry *FindClassEntry(char *pcClassName);

  int CreateObjectEntry(ItclObjectEntry *pObjectEntry);
  int DestroyObjectEntry(ItclObjectEntry *pObjectEntry);
  ItclObjectEntry *FindObjectEntry(char *pcObjectName);

public:
  static int ItclInit(Tcl_Interp *pInterp);
  static int DeleteCmd(ClientData pvObjectEntry, Tcl_Interp *pInterp, 
		       int argc, char *argv[]);
  int Delete(Tcl_Interp *pInterp, int argc, char *argv[]);
  static int ScopeCmd(ClientData pvObjectEntry, Tcl_Interp *pInterp, 
		      int argc, char *argv[]);
  int Scope(Tcl_Interp *pInterp, int argc, char *argv[]);

  ITCLCXX_API static ItclNameSpace *GetGlobal();

public:
  Tcl_Interp *GetInterp() {return m_pInterp;};

protected:
  static ItclNameSpace *m_pnsGlobal;

protected:
  int m_bInitialized;

  Tcl_Interp *m_pInterp;
  Tcl_HashTable m_hashClass;  
  Tcl_HashTable m_hashObject;
};


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////
// ItclObject

class ItclObject
{
public:
  ITCLCXX_API ItclObject();
  ITCLCXX_API virtual ~ItclObject();
  ITCLCXX_API virtual void Init();
  ITCLCXX_API virtual void Uninit();

//////////////////////////////////////////////////
// Itcl Built-In Methods
//
public:
  char *configure(int argc, char **argv);
  char *cget(int argc, char **argv);
  char *info(int argc, char **argv);
  int isa(char *pcClassName);

  virtual void Display();

protected:
  int SetField(char *pcFieldName, char *pcValue);

//////////////////////////////////////////////////
// Class Methods
//
public:
  static int ItclInit(Tcl_Interp *pInterp);

  static ItclObject *Allocate();
  static void Deallocate(ItclObject *pObject);

  ITCLCXX_API static inline Tcl_Interp *GetInterp() {return m_pInterp;};
  ITCLCXX_API static inline void SetInterp(Tcl_Interp *pInterp) {m_pInterp = pInterp;};
  ITCLCXX_API static inline int GetErrorCode() {return m_iErrorCode;};
  ITCLCXX_API static inline void SetErrorCode(int iErrorCode) {m_iErrorCode = iErrorCode;};

//////////////////////////////////////////////////
// Accessor Methods
//
public:
  inline ItclObjectEntry *GetObjectEntry() {return m_pObjectEntry;};
  inline void SetObjectEntry(ItclObjectEntry *pObjectEntry) {m_pObjectEntry = pObjectEntry;};
  inline char *GetName() {return GetObjectEntry()->GetName();};

//////////////////////////////////////////////////
// Class Variables
//
protected:
  ITCLCXX_API static ItclClassEntry *m_pItclClassEntry;
  static int m_iErrorCode;
  static Tcl_Interp *m_pInterp;

//////////////////////////////////////////////////
// Object Variables
//
protected:
  ItclObjectEntry *m_pObjectEntry;
};

#endif // __ITCLOBJECT_H__
