#ifndef __ITCLCXX_H__
#define __ITCLCXX_H__

#include <tcl.h>

int ItclCxxInit(Tcl_Interp *pInterp);

#endif // __FOO_H__
