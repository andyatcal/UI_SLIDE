#include "window.h"
#include "slideparser.h"
#include "slideworld.h"

#include "itcl.h"
#include "itk.h"

EXTERN int		TkConsoleInit(Tcl_Interp *interp);

//////////////////////////////////////////////////////////////////////
// Tcl/Tk Stuff
//

#ifdef WIN32

#define matherr _matherr
#else

// The following variable is a special hack that is needed in order for
// Sun shared libraries to be used for Tcl.
extern "C"
{
extern int matherr();
};

#endif //WIN32

int *tclDummyMathPtr = (int *) matherr;



// Called by Tk_Main() to let me init the modules (Togl) I will need.
int Tcl_AppInit(Tcl_Interp *pInterp);
VOID InitSLIDETCLGlobals(Tcl_Interp *pInterp);

//
// Tcl/Tk Stuff
//////////////////////////////////////////////////////////////////////

BOOL ParseCommandLine(UINT_32 &uiArgc, CHAR **ppcArgv);
VOID ConsumeArgument(UINT_32 *puiArgc, CHAR **ppcArgv, 
		     UINT_32 i);
VOID ConsumeArguments(UINT_32 *puiArgc, CHAR **ppcArgv, 
		      UINT_32 i, UINT_32 uiArgs);
VOID SkipArgument(UINT_32 *pi, CHAR ***pppc);
VOID PrintUsage();
BOOL LoadWorld();
VOID UnloadWorld();

// Main Design Studio Call Backs
int HandleOpen(ClientData clientData, Tcl_Interp *interp,
	       int argc, char **argv);
int HandleWrite(ClientData clientData, Tcl_Interp *interp, 
		int argc, char **argv);
int HandleWriteDot(ClientData clientData, Tcl_Interp *interp, 
		   int argc, char **argv);
int HandleExit(ClientData clientData, Tcl_Interp *interp, 
	       int argc, char **argv);

Tcl_Command gtclcmdHandleOpen = NULL;
Tcl_Command gtclcmdHandleWrite = NULL;
Tcl_Command gtclcmdHandleWriteDot = NULL;
Tcl_Command gtclcmdHandleExit = NULL;

static CHAR gpcBuffer[200];
static CHAR *gpcProgramName = NULL;
static CHAR *gpcInputFile = NULL;
static CHAR *gpcOutputFile = NULL;
static FILE *gfpOutputFile = NULL;
static CSLIDEParser *gpCSLIDEParser = NULL;

// the directory where the config files are kept. this value can be
// changed in unix with the environment variable SLIDE_HOME.
// SLIDE_HOME is examined in Tcl_AppInit
static CHAR *slideHome = "/project/cs/sequin/caffe/slide/lib/slide";

static CHAR *gpcMainConfigFile = NULL;

CHAR *GetMainConfigFile()
{
  return gpcMainConfigFile;
}

VOID SetMainConfigFile(CHAR *pcMainConfigFile)
{
  if ( gpcMainConfigFile != NULL )
    {
      delete []gpcMainConfigFile;
      gpcMainConfigFile = NULL;
    }
  gpcMainConfigFile = new CHAR[strlen(pcMainConfigFile)+1];
  ASSERT(gpcMainConfigFile != NULL );
  strcpy(gpcMainConfigFile, pcMainConfigFile);  
}


static CHAR *gpcUIConfigFile = NULL;

CHAR *GetUIConfigFile()
{
  return gpcUIConfigFile;
}

VOID SetUIConfigFile(CHAR *pcUIConfigFile)
{
  if ( gpcUIConfigFile != NULL )
    {
      delete []gpcUIConfigFile;
      gpcUIConfigFile = NULL;
    }
  gpcUIConfigFile = new CHAR[strlen(pcUIConfigFile)+1];
  ASSERT(gpcUIConfigFile != NULL );
  strcpy(gpcUIConfigFile, pcUIConfigFile);  
}

CHAR *GetFileDirPath (CHAR *pcFullPath)
{
  INT_32 iLastslash;
  iLastslash = -1;
  CHAR *temp;

  // Grab the directory name out of this fully-qualified filename
  // Is there a premade function to do this?  maybe...
  // 
  for (UINT_32 i=0; i< strlen (pcFullPath); i++)
  {
	  if (pcFullPath[i] == '/')
	  {
		  iLastslash = i;
	  }
  }
  if (iLastslash >= 0)
  {
	  // if not in current directory, CD there to be in the right
	  // directory.
	  //
	  temp = new char[iLastslash + 3];
	  strncpy ( temp, pcFullPath, iLastslash+1);
	  temp[iLastslash+1] = '\0';
  }
  else
  {
	  temp = new char[1];
	  temp[0] = '\0';
  }

  return temp;
}

const UINT_32 cuiSearchPathDirectoriesMax = 20;
CHAR *gppcSearchPathDirectories[cuiSearchPathDirectoriesMax];
UINT_32 guiSearchPathDirectories = 0;

int main(int argc, char **argv)
{
  UINT_32 uiArgc;
  CHAR **ppcArgv;


  // Make a copy of argc and argv so that we can take our 
  // arguments from it and modify it
  uiArgc = (UINT_32)argc;
  ppcArgv = new CHAR*[uiArgc];
  ASSERT( ppcArgv != NULL );
  memcpy(ppcArgv, argv, uiArgc*sizeof(CHAR*));

  // Parse the command line to find the input file name
  if ( !ParseCommandLine(uiArgc, ppcArgv) )
    {
      PrintUsage();
      exit(1);
    }

  printf("#");
  fflush(stdout);

  // This calls the event loop handler and only returns once the 
  // program is exited
  Tk_Main( (int)uiArgc, (char**)ppcArgv, Tcl_AppInit );

  return 0;
}

BOOL ParseCommandLine(UINT_32 &uiArgc, CHAR **ppcArgv)
{
  BOOL bCorrect;
  UINT_32 i, uiArgsMatched;
  CHAR **ppc;
  CHAR *pc;

  ASSERT( uiArgc > 0 );
  ASSERT( ppcArgv != NULL );

  bCorrect = TRUE;
  i = 0;
  ppc = ppcArgv;

  gpcProgramName = new CHAR[strlen(ppcArgv[i])+1];
  ASSERT( gpcProgramName != NULL );
  strcpy(gpcProgramName, ppcArgv[i]);
  //ConsumeArguments(&uiArgc, ppcArgv, 0, 1);
  i++;
  
  while ( i < uiArgc )
    {
      if ( *ppc[i] == '-' )
	{
	  pc = (ppc[i]) + 1;

	  switch ( *pc )
	    {
	    case 'f':
	      pc++;
	      // Tcl Init Files

	      switch ( *pc )
		{
		case 'm':
		  // main.tcl
  
		  if ( i+1 >= uiArgc )
		    {
		      fprintf(stderr, "Missing argument for option -fm\n");
		      return FALSE;
		    }
	      
		  pc = ppc[i+1];

		  SetMainConfigFile(pc);

		  uiArgsMatched = 2;
		  break;

		case 'w':
		  // window.tcl
  
		  if ( i+1 >= uiArgc )
		    {
		      fprintf(stderr, "Missing argument for option -fw\n");
		      return FALSE;
		    }
	      
		  pc = ppc[i+1];

		  SetUIConfigFile(pc);

		  uiArgsMatched = 2;
		  break;
		}
	      break;

	    case 'I':
	      pc++;
	      // Search Path Directory

	      if ( i+1 >= uiArgc )
		{
		  fprintf(stderr, "Missing argument for option -I\n");
		  return FALSE;
		}
	      
	      pc = ppc[i+1];
	      gppcSearchPathDirectories[guiSearchPathDirectories] = new CHAR[strlen(pc) + 1];
	      ASSERT( gppcSearchPathDirectories[guiSearchPathDirectories] != NULL );
	      strcpy(gppcSearchPathDirectories[guiSearchPathDirectories], pc);
	      guiSearchPathDirectories++;
	      uiArgsMatched = 2;
	      break;

	    default:
	      fprintf(stderr, "Unknown option: %s\n", ppc[i]);
	      return FALSE;
	    }

	  ASSERT( uiArgsMatched != 0 );
	  //if ( uiArgsMatched == 0 )
	  //  {
	  //    bCorrect = FALSE;
	  //    SkipArgument(&i, &ppc);
	  //  }
	  //else
	  //  {
	  ConsumeArguments(&uiArgc, ppcArgv, i, uiArgsMatched);
	  //  }
	}
      else
	{
	  break;
	}
    }

  if ( i == uiArgc )
    {
      return TRUE;
    }

  if ( !( i+1 == uiArgc) )
    {
      return FALSE;
    }

  gpcInputFile = new CHAR[strlen(ppcArgv[i])+1];
  ASSERT( gpcInputFile != NULL );
  strcpy(gpcInputFile, ppcArgv[i]);
  
  ConsumeArguments(&uiArgc, ppcArgv, i, 1);
	
  return bCorrect;
}

VOID ConsumeArgument(UINT_32 *puiArgc, CHAR **ppcArgv, UINT_32 i)
{
  ASSERT( puiArgc != NULL );
  ASSERT( ppcArgv != NULL );
  ASSERT( i+1 <= *puiArgc );

  memcpy((ppcArgv + i), (ppcArgv + i + 1), 
	 (*puiArgc - i - 1)*sizeof(CHAR*));
  (*puiArgc)--;
}

VOID ConsumeArguments(UINT_32 *puiArgc, CHAR **ppcArgv, 
		      UINT_32 i, UINT_32 uiArgs)
{
  ASSERT( puiArgc != NULL );
  ASSERT( ppcArgv != NULL );
  ASSERT( uiArgs > 0 );
  ASSERT( i+uiArgs <= *puiArgc );

  memcpy((ppcArgv + i), (ppcArgv + i + uiArgs), 
	 (*puiArgc - i - uiArgs)*sizeof(CHAR*));
  (*puiArgc) -= uiArgs;
}

VOID SkipArgument(UINT_32 *pi, CHAR ***pppc)
{
  ASSERT( pi != NULL );
  ASSERT( pppc != NULL );

  (*pi)++;
  (*pppc)++;
}
VOID PrintUsage()
{
  fprintf(stderr, "Usage: %s [-I search_path_directory]* input.slf\n", gpcProgramName);
}

BOOL LoadWorld()
{
  CSLIDEWorld *pCSLIDEWorld;

  UnloadWorld();

  ASSERT( gpcInputFile != NULL );
  gpCSLIDEParser = slide_InitParser(new CSLIDEParser, gpcInputFile,
				    (guiSearchPathDirectories == 0) ? ((CHAR**)NULL) : (gppcSearchPathDirectories), 
				    guiSearchPathDirectories);
  ASSERT( gpCSLIDEParser != NULL );

  fprintf(stderr, "Parsing...\n");
  pCSLIDEWorld = (CSLIDEWorld*)(gpCSLIDEParser->Parse());
  CSLIDEWorld::SetWorld((CSLIDEWorld*)(gpCSLIDEParser->GetAST()));
  if ( pCSLIDEWorld == NULL )
    {
      fprintf(stderr, "Compilation halted because of syntax errors.\n");
      return FALSE;
    }

  fprintf(stderr, "Checking Semantics...\n");
  if ( !pCSLIDEWorld->CheckSemantics() )
    {
      fprintf(stderr, "Semantic Checking Done: %ld Errors and %ld Warnings.\n",
	      pCSLIDEWorld->GetErrorCount(), 
	      pCSLIDEWorld->GetWarningCount());
      fprintf(stderr, "Compilation halted because of semantic errors.\n");
      return FALSE;
    }
  fprintf(stderr, "Semantic Checking Done: %ld Errors and %ld Warnings.\n",
	  pCSLIDEWorld->GetErrorCount(), pCSLIDEWorld->GetWarningCount());
  fprintf(stderr, "Compilation was successful.\n");

  CSLIDEWorld::GetWorld()->Preprocess();

  return TRUE;
}

VOID UnloadWorld()
{
  if ( CSLIDEWorld::GetWorld() != NULL )
    {
      CSLIDEWorld::GetWorld()->UninitTcl();
    }

  // Flush the Event Queue
  while ( Tk_DoOneEvent(TK_ALL_EVENTS|TK_DONT_WAIT) )
    {
    }

  if ( CSLIDEWorld::GetWorld() != NULL )
    {
      delete CSLIDEWorld::GetWorld();
      CSLIDEWorld::SetWorld(NULL);
    }

  if ( gpCSLIDEParser != NULL )
    {
      delete gpCSLIDEParser;
      gpCSLIDEParser = NULL;
    }
}

int Tcl_AppInit(Tcl_Interp *pInterp)
{
  INT_32 iCode;

  CSLIDEWorld::SetInterp(pInterp);

  // read SLIDE_HOME environment variable
#ifdef WIN32
  
#else
  char *envSlideHome = getenv("SLIDE_HOME");
  if (envSlideHome) {
    slideHome = envSlideHome;
  }
  // printf("SlideHome is: %s\n", slideHome);

#endif // WIN32


  CSLIDEWorld::SetInterp(pInterp);

   // Initialize Tcl, Tk, and Oot.
   if (Tcl_Init(pInterp) == TCL_ERROR)
     {
       return TCL_ERROR;
     }
   if (Tk_Init(pInterp) == TCL_ERROR) 
     {
       return TCL_ERROR;
     }
   if (Itcl_Init(pInterp) == TCL_ERROR) 
     {
       return TCL_ERROR;
     }
   if (Itk_Init(pInterp) == TCL_ERROR) 
     {
       return TCL_ERROR;
     }
    Tcl_StaticPackage(pInterp, "Itcl", Itcl_Init, Itcl_SafeInit);
    Tcl_StaticPackage(pInterp, "Itk", Itk_Init, (Tcl_PackageInitProc *) NULL);

    /*
     *  This is itkwish, so import all [incr Tcl] commands by
     *  default into the global namespace.  Fix up the autoloader
     *  to do the same.
     */
    if (Tcl_Import(pInterp, Tcl_GetGlobalNamespace(pInterp),
            "::itk::*", /* allowOverwrite */ 1) != TCL_OK) {
        return TCL_ERROR;
    }

    if (Tcl_Import(pInterp, Tcl_GetGlobalNamespace(pInterp),
            "::itcl::*", /* allowOverwrite */ 1) != TCL_OK) {
        return TCL_ERROR;
    }

    if (Tcl_Eval(pInterp, "auto_mkindex_parser::slavehook { _%@namespace import -force ::itcl::* ::itk::* }") != TCL_OK) {
        return TCL_ERROR;
    }

  if (Togl_Init(pInterp) == TCL_ERROR) 
    {
      return TCL_ERROR;
    }

#ifdef WIN32
  if (TkConsoleInit(pInterp) == TCL_ERROR) 
  {
    return TCL_ERROR;
  }
#endif // WIN32

  if (Oot_Init(pInterp) == TCL_ERROR) 
    {
      return TCL_ERROR;
    }

  if ( CWindow::CreateOotClass(pInterp) == TCL_ERROR )
    {
       return TCL_ERROR;
    }
  Togl_CreateFunc( CWindow::CBHandleToglCreate );
  Togl_DisplayFunc( CWindow::CBHandleDisplay );
  Togl_ReshapeFunc( CWindow::CBHandleReshape );
  Togl_DestroyFunc( CWindow::CBHandleDestroy );


  if ( CSLIDEParser::CreateOotClass(pInterp) == TCL_ERROR )
    {
       return TCL_ERROR;
    }

  InitSLIDETCLGlobals(pInterp);

  strcpy(gpcBuffer, "slideOpen");
  gtclcmdHandleOpen = Tcl_CreateCommand(pInterp, gpcBuffer, HandleOpen, NULL, NULL);
  if ( gtclcmdHandleOpen == NULL )
    {
      return TCL_ERROR;
    }
  strcpy(gpcBuffer, "slideWrite");
  gtclcmdHandleWrite = Tcl_CreateCommand(pInterp, gpcBuffer, HandleWrite, NULL, NULL);
  if ( gtclcmdHandleWrite == NULL )
    {
      return TCL_ERROR;
    }
  strcpy(gpcBuffer, "slideWriteDot");
  gtclcmdHandleWriteDot = Tcl_CreateCommand(pInterp, gpcBuffer, HandleWriteDot, NULL, NULL);
  if ( gtclcmdHandleWriteDot == NULL )
    {
      return TCL_ERROR;
    }
  strcpy(gpcBuffer, "slideExit");
  gtclcmdHandleExit = Tcl_CreateCommand(pInterp, gpcBuffer, HandleExit, NULL, NULL);
  if ( gtclcmdHandleExit == NULL )
    {
      return TCL_ERROR;
    }

  //////////////////////////////////////////////////
  // Window UI Config File
  if ( GetMainConfigFile() == NULL )
#ifdef WIN32
    {
      HKEY hkey, hkeyResult;
      LONG lResult;
      DWORD dwSize;
      ULONG ulType;

      
      lResult = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\MainConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      hkey = hkeyResult;
      
      lResult = RegOpenKeyEx(hkey, "UC Berkeley", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\MainConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;
      
      lResult = RegOpenKeyEx(hkey, "SLIDE", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\MainConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;

      lResult = RegOpenKeyEx(hkey, "1.0", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\MainConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;

      lResult = RegOpenKeyEx(hkey, "slide", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\MainConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;

      dwSize = 200;
      lResult = RegQueryValueEx(hkeyResult, "MainConfigFile", 0, &ulType, (LPBYTE)gpcBuffer, &dwSize);
      if ( lResult != ERROR_SUCCESS || ulType != REG_SZ )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\MainConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}

      SetMainConfigFile(gpcBuffer);
    }
#else // WIN32
    {
      sprintf(gpcBuffer, "%s/main.tcl", slideHome);
      SetMainConfigFile(gpcBuffer); 
    }
#endif // WIN32

  // Set slide LIB path, for auxillary stuff needed by main and other misc stuff
  //
  CHAR *pDirname;

  pDirname = GetFileDirPath ( GetMainConfigFile() );

  if (!strcmp (pDirname,""))
    pDirname = ".";

  Tcl_SetVar(pInterp, "SLF_LIBPATH", pDirname, TCL_GLOBAL_ONLY);

  iCode = Tcl_EvalFile(pInterp, GetMainConfigFile()); 
  if ( iCode != TCL_OK )
    {
      sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error opening Main configure file: \\\"%s\\\"\\n Exiting program.\"", GetMainConfigFile());
      iCode = Tcl_Eval(pInterp, gpcBuffer); 
      ASSERT( iCode == TCL_OK );
      return TCL_ERROR;
    }

  //
  // End  : MainConfigFile
  //////////////////////////////////////////////////////////////////////



  //////////////////////////////////////////////////////////////////////
  // START: UIConfigFile
  //
  if ( GetUIConfigFile() == NULL )
#ifdef WIN32
    {
      HKEY hkey, hkeyResult;
      LONG lResult;
      DWORD dwSize;
      ULONG ulType;
      
      lResult = RegOpenKeyEx(HKEY_CURRENT_USER, "Software", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\UIConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      hkey = hkeyResult;
      
      lResult = RegOpenKeyEx(hkey, "UC Berkeley", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\UIConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;
      
      lResult = RegOpenKeyEx(hkey, "SLIDE", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\UIConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;

      lResult = RegOpenKeyEx(hkey, "1.0", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\UIConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;

      lResult = RegOpenKeyEx(hkey, "slide", 0, KEY_READ, &hkeyResult);
      if ( lResult != ERROR_SUCCESS )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\UIConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}
      ASSERT( lResult == ERROR_SUCCESS );
      hkey = hkeyResult;

      dwSize = 200;
      lResult = RegQueryValueEx(hkeyResult, "UIConfigFile", 0, &ulType, (LPBYTE)gpcBuffer, &dwSize);
      if ( lResult != ERROR_SUCCESS || ulType != REG_SZ )
	{
	  sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error reading registry string value: \\\"HKEY_CURRENT_USER\\\\Software\\\\UC Berkeley\\\\SLIDE\\\\1.0\\\\slide\\\\UIConfigFile\\\"\\n Exiting program.\"");
	  iCode = Tcl_Eval(pInterp, gpcBuffer); 
	  ASSERT( iCode == TCL_OK );
	  exit(1);
	}

      SetUIConfigFile(gpcBuffer);
    }
#else // WIN32
    {     
      sprintf(gpcBuffer, "%s/window.tcl", slideHome);
      SetUIConfigFile(gpcBuffer);
    }
#endif // WIN32

  ASSERT( gpcUIConfigFile != NULL );
  iCode = Tcl_EvalFile(pInterp, gpcUIConfigFile); 
  if ( iCode != TCL_OK )
    {
      sprintf(gpcBuffer, "tk_messageBox -icon error -type ok -default ok -message \"Error opening UI configure file: \\\"%s\\\"\\n Exiting program.\"", gpcUIConfigFile);
      iCode = Tcl_Eval(pInterp, gpcBuffer); 
      if ( iCode != TCL_OK )
	{
	  printf("MessageBox returned: \"%s\"\n", pInterp->result);
	}
      ASSERT( iCode == TCL_OK );
      exit(1);
    }
  //
  // END  : UIConfigFile
  //////////////////////////////////////////////////////////////////////


  if ( gpcInputFile != NULL )
    {
      LoadWorld();
    }
/*
  // Load the world from the file into memory
  if ( !LoadWorld() )
    {
      exit(2);
    }

  // This should Allocate all the windows for the application
  CSLIDEWorld::GetWorld()->Preprocess();
*/
  return TCL_OK;
}

VOID InitSLIDETCLGlobals(Tcl_Interp *pInterp)
{
  UINT_32 i;

  ASSERT( pInterp != NULL );

  // Set up SLIDE Globals like SLF_TIME, SLF_MOUSE_X, SLF_MOUSE_Y
  Tcl_SetVar(pInterp, "SLF_PI", "3.1415927", TCL_GLOBAL_ONLY);
  Tcl_SetVar(pInterp, "SLF_TIME", "0", TCL_GLOBAL_ONLY);
  Tcl_SetVar(pInterp, "SLF_FRAME", "0", TCL_GLOBAL_ONLY);
  Tcl_SetVar(pInterp, "SLF_START_FRAME", "0", TCL_GLOBAL_ONLY);
  Tcl_SetVar(pInterp, "SLF_END_FRAME", "0", TCL_GLOBAL_ONLY);

  // On Off flags
  for ( i = 0; i < slideoftSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDEOnOffReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Solid flags
  for ( i = 0; i < slidestSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDESolidReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Shading flags
  gcppcSLIDEShadingReservedWords[slideshtSLF_INHERIT] = 
    gcppcSLIDEReservedWords[sliderwtSLF_INHERIT];
  for ( i = 0; i < slideshtSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDEShadingReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // LOD flags
  gcppcSLIDELODReservedWords[slidelodtSLF_OFF] = 
    gcppcSLIDEOnOffReservedWords[slideoftSLF_OFF];
  for ( i = 0; i < slidelodtSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDELODReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Projection flags
  for ( i = 0; i < slidepjtSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDEProjectionReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Lighting Type flags
  for ( i = 0; i < slideltSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDELightReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Fog Type flags
  for ( i = 0; i < slidefogtSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDEFogReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Stencil flags
  for ( i = 0; i < slidesttSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDEStencilReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Aspect Ratio flags
  for ( i = 0; i < slideartSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDEAspectRatioReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Subdivision flags
  for ( i = 0; i < slidesubtSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDESubdivisionReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

  // Subdivision flags
  for ( i = 0; i < slidecuitSize; i++ )
    {
      sprintf(gpcBuffer, "%ld", i);
      Tcl_SetVar(pInterp, gcppcSLIDECameraUserInterfaceReservedWords[i], 
		 gpcBuffer, TCL_GLOBAL_ONLY);
    }

}

int HandleOpen(ClientData /*clientData*/, Tcl_Interp *pInterp, 
	       int /*argc*/, char ** /*argv*/)
{
  if ( gpcInputFile != NULL )
    {
      delete gpcInputFile;
      gpcInputFile = NULL;
    }

  INT_32 iCode;
  UINT_32 uiLength;
  CHAR *pDirname;
  
  sprintf(gpcBuffer, "tk_getOpenFile -defaultextension .slf -filetypes {{\"SLIDE Files\" {.slf}}}");
  iCode = Tcl_Eval(pInterp, gpcBuffer); 
  ASSERT( iCode == TCL_OK );
  
  uiLength = strlen(pInterp->result);
  if ( uiLength == 0 )
    {
      // The user hit Cancel
      return TCL_OK;
    }
      
  ASSERT( pInterp->result != NULL );
  gpcInputFile = new CHAR[uiLength + 1];
  ASSERT( gpcInputFile != NULL );
  strcpy(gpcInputFile, pInterp->result);


  pDirname = GetFileDirPath ( gpcInputFile );
  sprintf(gpcBuffer, "cd %s", pDirname);
  delete[] pDirname;
	  
  iCode = Tcl_Eval(pInterp, gpcBuffer); 
  ASSERT( iCode == TCL_OK );


  LoadWorld();

  return TCL_OK;
}

int HandleWrite(ClientData /*clientData*/, Tcl_Interp *pInterp, 
		int /*argc*/, char ** /*argv*/)
{
  if ( CSLIDEWorld::GetWorld() != NULL )
    {
      INT_32 iCode;
      UINT_32 uiLength;
      
      sprintf(gpcBuffer, "tk_getSaveFile -defaultextension .slf -filetypes {{\"SLIDE Files\" {.slf}}}");
      iCode = Tcl_Eval(pInterp, gpcBuffer); 
      ASSERT( iCode == TCL_OK );
      
      uiLength = strlen(pInterp->result);
      if ( uiLength == 0 )
	{
	  // The user hit Cancel
	  return TCL_OK;
	}
      
      if ( gpcOutputFile != NULL )
	{
	  delete []gpcOutputFile;
	  gpcOutputFile = NULL;
	}
      ASSERT( gfpOutputFile == NULL );
      
      ASSERT( pInterp->result != NULL );
      gpcOutputFile = new CHAR[uiLength + 1];
      ASSERT( gpcOutputFile != NULL );
      strcpy(gpcOutputFile, pInterp->result);
      
      while ( gfpOutputFile == NULL )
	{
	  gfpOutputFile = fopen(gpcOutputFile, "w");
	  if ( gfpOutputFile == NULL )
	    {
	      sprintf(gpcBuffer, "tk_messageBox -icon error -message \"File \\\"%s\\\" cannot be written.\" -type retrycancel -default retry", gpcOutputFile);
	      iCode = Tcl_Eval(pInterp, gpcBuffer); 
	      ASSERT( iCode == TCL_OK );
	      
	      if ( strcmp(pInterp->result, "cancel") == 0 )
		{
		  // Cancel
		  return TCL_OK;
		}
	    }
	}
      
      CSLIDEWorld::GetWorld()->WriteSLIDE(gfpOutputFile);

      if ( gfpOutputFile != stdout )
	{
	  ASSERT( gfpOutputFile != NULL );
	  fclose(gfpOutputFile);
	}
      
      gfpOutputFile = NULL;
    }

  return TCL_OK;
}

int HandleWriteDot(ClientData /*clientData*/, Tcl_Interp *pInterp, 
		   int /*argc*/, char ** /*argv*/)
{
  if ( CSLIDEWorld::GetWorld() != NULL )
    {
      INT_32 iCode;
      UINT_32 uiLength;
      
      sprintf(gpcBuffer, "tk_getSaveFile -defaultextension .dot -filetypes {{\"Dot Files\" {.dot}}}");
      iCode = Tcl_Eval(pInterp, gpcBuffer); 
      ASSERT( iCode == TCL_OK );
      
      uiLength = strlen(pInterp->result);
      if ( uiLength == 0 )
	{
	  // The user hit Cancel
	  return TCL_OK;
	}
      
      if ( gpcOutputFile != NULL )
	{
	  delete []gpcOutputFile;
	  gpcOutputFile = NULL;
	}
      ASSERT( gfpOutputFile == NULL );
      
      ASSERT( pInterp->result != NULL );
      gpcOutputFile = new CHAR[uiLength + 1];
      ASSERT( gpcOutputFile != NULL );
      strcpy(gpcOutputFile, pInterp->result);
      
      while ( gfpOutputFile == NULL )
	{
	  gfpOutputFile = fopen(gpcOutputFile, "w");
	  if ( gfpOutputFile == NULL )
	    {
	      sprintf(gpcBuffer, "tk_messageBox -icon error -message \"File \\\"%s\\\" cannot be written.\" -type retrycancel -default retry", gpcOutputFile);
	      iCode = Tcl_Eval(pInterp, gpcBuffer); 
	      ASSERT( iCode == TCL_OK );
	      
	      if ( strcmp(pInterp->result, "cancel") == 0 )
		{
		  // Cancel
		  return TCL_OK;
		}
	    }
	}
      
      CSLIDEWorld::GetWorld()->WriteDot(gfpOutputFile);

      if ( gfpOutputFile != stdout )
	{
	  ASSERT( gfpOutputFile != NULL );
	  fclose(gfpOutputFile);
	}
      
      gfpOutputFile = NULL;
    }

  return TCL_OK;
}

int HandleExit(ClientData /*clientData*/, Tcl_Interp * /*interp*/, 
	       int /*argc*/, char ** /*argv*/)
{
  exit(0);

  return TCL_OK;
}

